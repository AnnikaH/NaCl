# Generated from NaCl.g4 by ANTLR 4.7
from antlr4 import *

# This class defines a complete generic visitor for a parse tree produced by NaClParser.

class NaClVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by NaClParser#value.
    def visitValue(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#primitive_type.
    def visitPrimitive_type(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#numeric_type.
    def visitNumeric_type(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#bool_val.
    def visitBool_val(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#ipv4_cidr.
    def visitIpv4_cidr(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#cidr_mask.
    def visitCidr_mask(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#integer.
    def visitInteger(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#decimal.
    def visitDecimal(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#ipv4_addr.
    def visitIpv4_addr(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#ipv6_addr.
    def visitIpv6_addr(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#rng.
    def visitRng(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#string.
    def visitString(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#value_name.
    def visitValue_name(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#obj.
    def visitObj(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#key_value_list.
    def visitKey_value_list(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#key_value_pair.
    def visitKey_value_pair(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#key.
    def visitKey(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#list_t.
    def visitList_t(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#value_list.
    def visitValue_list(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#function.
    def visitFunction(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#type_t.
    def visitType_t(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#subtype.
    def visitSubtype(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#name.
    def visitName(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#body.
    def visitBody(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#body_element.
    def visitBody_element(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#action.
    def visitAction(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#conditional.
    def visitConditional(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#bool_expr.
    def visitBool_expr(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#comparison.
    def visitComparison(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#lhs.
    def visitLhs(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#rhs.
    def visitRhs(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#logical_operator.
    def visitLogical_operator(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#comparison_operator.
    def visitComparison_operator(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#typed_initializer.
    def visitTyped_initializer(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#initializer.
    def visitInitializer(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#expr.
    def visitExpr(self, ctx):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by NaClParser#prog.
    def visitProg(self, ctx):
        return self.visitChildren(ctx)


