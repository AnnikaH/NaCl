# Generated from NaCl.g4 by ANTLR 4.7
from antlr4 import *

# This class defines a complete listener for a parse tree produced by NaClParser.
class NaClListener(ParseTreeListener):

    # Enter a parse tree produced by NaClParser#value.
    def enterValue(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#value.
    def exitValue(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#primitive_type.
    def enterPrimitive_type(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#primitive_type.
    def exitPrimitive_type(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#numeric_type.
    def enterNumeric_type(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#numeric_type.
    def exitNumeric_type(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#bool_val.
    def enterBool_val(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#bool_val.
    def exitBool_val(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#ipv4_cidr.
    def enterIpv4_cidr(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#ipv4_cidr.
    def exitIpv4_cidr(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#cidr_mask.
    def enterCidr_mask(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#cidr_mask.
    def exitCidr_mask(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#integer.
    def enterInteger(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#integer.
    def exitInteger(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#decimal.
    def enterDecimal(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#decimal.
    def exitDecimal(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#ipv4_addr.
    def enterIpv4_addr(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#ipv4_addr.
    def exitIpv4_addr(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#ipv6_addr.
    def enterIpv6_addr(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#ipv6_addr.
    def exitIpv6_addr(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#rng.
    def enterRng(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#rng.
    def exitRng(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#string.
    def enterString(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#string.
    def exitString(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#value_name.
    def enterValue_name(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#value_name.
    def exitValue_name(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#obj.
    def enterObj(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#obj.
    def exitObj(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#key_value_list.
    def enterKey_value_list(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#key_value_list.
    def exitKey_value_list(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#key_value_pair.
    def enterKey_value_pair(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#key_value_pair.
    def exitKey_value_pair(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#key.
    def enterKey(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#key.
    def exitKey(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#list_t.
    def enterList_t(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#list_t.
    def exitList_t(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#value_list.
    def enterValue_list(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#value_list.
    def exitValue_list(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#function.
    def enterFunction(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#function.
    def exitFunction(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#type_t.
    def enterType_t(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#type_t.
    def exitType_t(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#subtype.
    def enterSubtype(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#subtype.
    def exitSubtype(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#name.
    def enterName(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#name.
    def exitName(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#body.
    def enterBody(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#body.
    def exitBody(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#body_element.
    def enterBody_element(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#body_element.
    def exitBody_element(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#action.
    def enterAction(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#action.
    def exitAction(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#conditional.
    def enterConditional(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#conditional.
    def exitConditional(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#bool_expr.
    def enterBool_expr(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#bool_expr.
    def exitBool_expr(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#comparison.
    def enterComparison(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#comparison.
    def exitComparison(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#lhs.
    def enterLhs(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#lhs.
    def exitLhs(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#rhs.
    def enterRhs(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#rhs.
    def exitRhs(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#logical_operator.
    def enterLogical_operator(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#logical_operator.
    def exitLogical_operator(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#comparison_operator.
    def enterComparison_operator(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#comparison_operator.
    def exitComparison_operator(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#typed_initializer.
    def enterTyped_initializer(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#typed_initializer.
    def exitTyped_initializer(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#initializer.
    def enterInitializer(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#initializer.
    def exitInitializer(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#expr.
    def enterExpr(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#expr.
    def exitExpr(self, ctx):
        pass


    # Enter a parse tree produced by NaClParser#prog.
    def enterProg(self, ctx):
        pass

    # Exit a parse tree produced by NaClParser#prog.
    def exitProg(self, ctx):
        pass


