# Generated from NaCl.g4 by ANTLR 4.7
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3")
        buf.write(u"(\u0152\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t")
        buf.write(u"\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write(u"\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4")
        buf.write(u"\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30")
        buf.write(u"\t\30\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t")
        buf.write(u"\35\4\36\t\36\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4$")
        buf.write(u"\t$\4%\t%\4&\t&\3\2\3\2\3\2\3\2\3\2\3\2\5\2S\n\2\3\3")
        buf.write(u"\3\3\3\3\5\3X\n\3\3\4\3\4\3\4\3\4\5\4^\n\4\3\5\3\5\3")
        buf.write(u"\6\3\6\3\6\3\7\3\7\3\7\3\b\6\bi\n\b\r\b\16\bj\3\b\3\b")
        buf.write(u"\3\b\6\bp\n\b\r\b\16\bq\3\b\5\bu\n\b\3\t\6\tx\n\t\r\t")
        buf.write(u"\16\ty\3\t\3\t\6\t~\n\t\r\t\16\t\177\3\t\3\t\3\t\6\t")
        buf.write(u"\u0085\n\t\r\t\16\t\u0086\3\t\3\t\6\t\u008b\n\t\r\t\16")
        buf.write(u"\t\u008c\3\t\5\t\u0090\n\t\3\n\3\n\3\n\3\n\3\n\3\n\3")
        buf.write(u"\n\3\n\3\13\3\13\3\f\3\f\3\f\3\f\3\r\3\r\3\r\7\r\u00a3")
        buf.write(u"\n\r\f\r\16\r\u00a6\13\r\3\r\3\r\3\16\3\16\3\16\3\16")
        buf.write(u"\5\16\u00ae\n\16\3\17\3\17\3\17\3\17\3\20\3\20\3\20\7")
        buf.write(u"\20\u00b7\n\20\f\20\16\20\u00ba\13\20\3\20\3\20\3\21")
        buf.write(u"\3\21\3\21\3\21\3\22\3\22\3\23\3\23\3\23\3\23\3\24\3")
        buf.write(u"\24\3\24\7\24\u00cb\n\24\f\24\16\24\u00ce\13\24\3\24")
        buf.write(u"\3\24\3\25\3\25\3\25\3\25\3\25\5\25\u00d7\n\25\3\25\3")
        buf.write(u"\25\3\25\3\25\3\26\3\26\3\27\3\27\3\30\3\30\3\31\6\31")
        buf.write(u"\u00e4\n\31\r\31\16\31\u00e5\3\32\3\32\3\32\5\32\u00eb")
        buf.write(u"\n\32\3\33\3\33\3\33\3\33\5\33\u00f1\n\33\3\33\3\33\5")
        buf.write(u"\33\u00f5\n\33\3\34\3\34\3\34\3\34\3\34\3\34\3\34\3\34")
        buf.write(u"\3\34\3\34\3\34\3\34\5\34\u0103\n\34\3\35\3\35\5\35\u0107")
        buf.write(u"\n\35\3\35\3\35\5\35\u010b\n\35\3\35\3\35\5\35\u010f")
        buf.write(u"\n\35\3\35\3\35\3\35\3\35\3\35\5\35\u0116\n\35\3\35\3")
        buf.write(u"\35\3\35\3\35\3\35\5\35\u011d\n\35\3\35\3\35\3\35\3\35")
        buf.write(u"\3\35\3\35\5\35\u0125\n\35\3\35\3\35\3\35\3\35\7\35\u012b")
        buf.write(u"\n\35\f\35\16\35\u012e\13\35\3\36\3\36\3\36\3\36\3\37")
        buf.write(u"\3\37\3 \3 \3!\3!\3\"\3\"\3#\3#\3#\3#\3$\3$\3$\3$\3%")
        buf.write(u"\3%\3%\3%\5%\u0148\n%\3&\7&\u014b\n&\f&\16&\u014e\13")
        buf.write(u"&\3&\3&\3&\2\38\'\2\4\6\b\n\f\16\20\22\24\26\30\32\34")
        buf.write(u"\36 \"$&(*,.\60\62\64\668:<>@BDFHJ\2\6\3\2\3\4\3\2\25")
        buf.write(u"\25\3\2\35\36\3\2\26\34\2\u0158\2R\3\2\2\2\4W\3\2\2\2")
        buf.write(u"\6]\3\2\2\2\b_\3\2\2\2\na\3\2\2\2\fd\3\2\2\2\16t\3\2")
        buf.write(u"\2\2\20\u008f\3\2\2\2\22\u0091\3\2\2\2\24\u0099\3\2\2")
        buf.write(u"\2\26\u009b\3\2\2\2\30\u009f\3\2\2\2\32\u00ad\3\2\2\2")
        buf.write(u"\34\u00af\3\2\2\2\36\u00b8\3\2\2\2 \u00bd\3\2\2\2\"\u00c1")
        buf.write(u"\3\2\2\2$\u00c3\3\2\2\2&\u00cc\3\2\2\2(\u00d1\3\2\2\2")
        buf.write(u"*\u00dc\3\2\2\2,\u00de\3\2\2\2.\u00e0\3\2\2\2\60\u00e3")
        buf.write(u"\3\2\2\2\62\u00ea\3\2\2\2\64\u00f4\3\2\2\2\66\u00f6\3")
        buf.write(u"\2\2\28\u0124\3\2\2\2:\u012f\3\2\2\2<\u0133\3\2\2\2>")
        buf.write(u"\u0135\3\2\2\2@\u0137\3\2\2\2B\u0139\3\2\2\2D\u013b\3")
        buf.write(u"\2\2\2F\u013f\3\2\2\2H\u0147\3\2\2\2J\u014c\3\2\2\2L")
        buf.write(u"S\5\4\3\2MS\5\26\f\2NS\5\30\r\2OS\5\32\16\2PS\5\34\17")
        buf.write(u"\2QS\5$\23\2RL\3\2\2\2RM\3\2\2\2RN\3\2\2\2RO\3\2\2\2")
        buf.write(u"RP\3\2\2\2RQ\3\2\2\2S\3\3\2\2\2TX\5\6\4\2UX\5\b\5\2V")
        buf.write(u"X\5\n\6\2WT\3\2\2\2WU\3\2\2\2WV\3\2\2\2X\5\3\2\2\2Y^")
        buf.write(u"\5\16\b\2Z^\5\20\t\2[^\5\22\n\2\\^\5\24\13\2]Y\3\2\2")
        buf.write(u"\2]Z\3\2\2\2][\3\2\2\2]\\\3\2\2\2^\7\3\2\2\2_`\t\2\2")
        buf.write(u"\2`\t\3\2\2\2ab\5\22\n\2bc\5\f\7\2c\13\3\2\2\2de\7\n")
        buf.write(u"\2\2ef\5\16\b\2f\r\3\2\2\2gi\7\b\2\2hg\3\2\2\2ij\3\2")
        buf.write(u"\2\2jh\3\2\2\2jk\3\2\2\2ku\3\2\2\2lm\7\23\2\2mo\7\t\2")
        buf.write(u"\2np\7\b\2\2on\3\2\2\2pq\3\2\2\2qo\3\2\2\2qr\3\2\2\2")
        buf.write(u"rs\3\2\2\2su\7\24\2\2th\3\2\2\2tl\3\2\2\2u\17\3\2\2\2")
        buf.write(u"vx\7\b\2\2wv\3\2\2\2xy\3\2\2\2yw\3\2\2\2yz\3\2\2\2z{")
        buf.write(u"\3\2\2\2{}\7\13\2\2|~\7\b\2\2}|\3\2\2\2~\177\3\2\2\2")
        buf.write(u"\177}\3\2\2\2\177\u0080\3\2\2\2\u0080\u0090\3\2\2\2\u0081")
        buf.write(u"\u0082\7\23\2\2\u0082\u0084\7\t\2\2\u0083\u0085\7\b\2")
        buf.write(u"\2\u0084\u0083\3\2\2\2\u0085\u0086\3\2\2\2\u0086\u0084")
        buf.write(u"\3\2\2\2\u0086\u0087\3\2\2\2\u0087\u0088\3\2\2\2\u0088")
        buf.write(u"\u008a\7\13\2\2\u0089\u008b\7\b\2\2\u008a\u0089\3\2\2")
        buf.write(u"\2\u008b\u008c\3\2\2\2\u008c\u008a\3\2\2\2\u008c\u008d")
        buf.write(u"\3\2\2\2\u008d\u008e\3\2\2\2\u008e\u0090\7\24\2\2\u008f")
        buf.write(u"w\3\2\2\2\u008f\u0081\3\2\2\2\u0090\21\3\2\2\2\u0091")
        buf.write(u"\u0092\7\b\2\2\u0092\u0093\7\13\2\2\u0093\u0094\7\b\2")
        buf.write(u"\2\u0094\u0095\7\13\2\2\u0095\u0096\7\b\2\2\u0096\u0097")
        buf.write(u"\7\13\2\2\u0097\u0098\7\b\2\2\u0098\23\3\2\2\2\u0099")
        buf.write(u"\u009a\7\7\2\2\u009a\25\3\2\2\2\u009b\u009c\5\6\4\2\u009c")
        buf.write(u"\u009d\7\t\2\2\u009d\u009e\5\6\4\2\u009e\27\3\2\2\2\u009f")
        buf.write(u"\u00a4\7\25\2\2\u00a0\u00a3\n\3\2\2\u00a1\u00a3\7\5\2")
        buf.write(u"\2\u00a2\u00a0\3\2\2\2\u00a2\u00a1\3\2\2\2\u00a3\u00a6")
        buf.write(u"\3\2\2\2\u00a4\u00a2\3\2\2\2\u00a4\u00a5\3\2\2\2\u00a5")
        buf.write(u"\u00a7\3\2\2\2\u00a6\u00a4\3\2\2\2\u00a7\u00a8\7\25\2")
        buf.write(u"\2\u00a8\31\3\2\2\2\u00a9\u00ae\7(\2\2\u00aa\u00ab\7")
        buf.write(u"(\2\2\u00ab\u00ac\7\13\2\2\u00ac\u00ae\5\32\16\2\u00ad")
        buf.write(u"\u00a9\3\2\2\2\u00ad\u00aa\3\2\2\2\u00ae\33\3\2\2\2\u00af")
        buf.write(u"\u00b0\7\17\2\2\u00b0\u00b1\5\36\20\2\u00b1\u00b2\7\20")
        buf.write(u"\2\2\u00b2\35\3\2\2\2\u00b3\u00b4\5 \21\2\u00b4\u00b5")
        buf.write(u"\7\r\2\2\u00b5\u00b7\3\2\2\2\u00b6\u00b3\3\2\2\2\u00b7")
        buf.write(u"\u00ba\3\2\2\2\u00b8\u00b6\3\2\2\2\u00b8\u00b9\3\2\2")
        buf.write(u"\2\u00b9\u00bb\3\2\2\2\u00ba\u00b8\3\2\2\2\u00bb\u00bc")
        buf.write(u"\5 \21\2\u00bc\37\3\2\2\2\u00bd\u00be\5\"\22\2\u00be")
        buf.write(u"\u00bf\7\f\2\2\u00bf\u00c0\5\2\2\2\u00c0!\3\2\2\2\u00c1")
        buf.write(u"\u00c2\7(\2\2\u00c2#\3\2\2\2\u00c3\u00c4\7\21\2\2\u00c4")
        buf.write(u"\u00c5\5&\24\2\u00c5\u00c6\7\22\2\2\u00c6%\3\2\2\2\u00c7")
        buf.write(u"\u00c8\5\2\2\2\u00c8\u00c9\7\r\2\2\u00c9\u00cb\3\2\2")
        buf.write(u"\2\u00ca\u00c7\3\2\2\2\u00cb\u00ce\3\2\2\2\u00cc\u00ca")
        buf.write(u"\3\2\2\2\u00cc\u00cd\3\2\2\2\u00cd\u00cf\3\2\2\2\u00ce")
        buf.write(u"\u00cc\3\2\2\2\u00cf\u00d0\5\2\2\2\u00d0\'\3\2\2\2\u00d1")
        buf.write(u"\u00d2\5*\26\2\u00d2\u00d3\7\f\2\2\u00d3\u00d4\7\f\2")
        buf.write(u"\2\u00d4\u00d6\5,\27\2\u00d5\u00d7\5.\30\2\u00d6\u00d5")
        buf.write(u"\3\2\2\2\u00d6\u00d7\3\2\2\2\u00d7\u00d8\3\2\2\2\u00d8")
        buf.write(u"\u00d9\7\17\2\2\u00d9\u00da\5\60\31\2\u00da\u00db\7\20")
        buf.write(u"\2\2\u00db)\3\2\2\2\u00dc\u00dd\7(\2\2\u00dd+\3\2\2\2")
        buf.write(u"\u00de\u00df\7(\2\2\u00df-\3\2\2\2\u00e0\u00e1\7(\2\2")
        buf.write(u"\u00e1/\3\2\2\2\u00e2\u00e4\5\62\32\2\u00e3\u00e2\3\2")
        buf.write(u"\2\2\u00e4\u00e5\3\2\2\2\u00e5\u00e3\3\2\2\2\u00e5\u00e6")
        buf.write(u"\3\2\2\2\u00e6\61\3\2\2\2\u00e7\u00eb\5(\25\2\u00e8\u00eb")
        buf.write(u"\5\64\33\2\u00e9\u00eb\5\66\34\2\u00ea\u00e7\3\2\2\2")
        buf.write(u"\u00ea\u00e8\3\2\2\2\u00ea\u00e9\3\2\2\2\u00eb\63\3\2")
        buf.write(u"\2\2\u00ec\u00f5\5.\30\2\u00ed\u00ee\5.\30\2\u00ee\u00f0")
        buf.write(u"\7\23\2\2\u00ef\u00f1\5&\24\2\u00f0\u00ef\3\2\2\2\u00f0")
        buf.write(u"\u00f1\3\2\2\2\u00f1\u00f2\3\2\2\2\u00f2\u00f3\7\24\2")
        buf.write(u"\2\u00f3\u00f5\3\2\2\2\u00f4\u00ec\3\2\2\2\u00f4\u00ed")
        buf.write(u"\3\2\2\2\u00f5\65\3\2\2\2\u00f6\u00f7\7 \2\2\u00f7\u00f8")
        buf.write(u"\7\23\2\2\u00f8\u00f9\58\35\2\u00f9\u00fa\7\24\2\2\u00fa")
        buf.write(u"\u00fb\7\17\2\2\u00fb\u00fc\5\60\31\2\u00fc\u0102\7\20")
        buf.write(u"\2\2\u00fd\u00fe\7!\2\2\u00fe\u00ff\7\17\2\2\u00ff\u0100")
        buf.write(u"\5\60\31\2\u0100\u0101\7\20\2\2\u0101\u0103\3\2\2\2\u0102")
        buf.write(u"\u00fd\3\2\2\2\u0102\u0103\3\2\2\2\u0103\67\3\2\2\2\u0104")
        buf.write(u"\u0106\b\35\1\2\u0105\u0107\7\37\2\2\u0106\u0105\3\2")
        buf.write(u"\2\2\u0106\u0107\3\2\2\2\u0107\u0108\3\2\2\2\u0108\u0125")
        buf.write(u"\5\2\2\2\u0109\u010b\7\37\2\2\u010a\u0109\3\2\2\2\u010a")
        buf.write(u"\u010b\3\2\2\2\u010b\u010c\3\2\2\2\u010c\u0125\5:\36")
        buf.write(u"\2\u010d\u010f\7\37\2\2\u010e\u010d\3\2\2\2\u010e\u010f")
        buf.write(u"\3\2\2\2\u010f\u0110\3\2\2\2\u0110\u0111\7\23\2\2\u0111")
        buf.write(u"\u0112\5:\36\2\u0112\u0113\7\24\2\2\u0113\u0125\3\2\2")
        buf.write(u"\2\u0114\u0116\7\37\2\2\u0115\u0114\3\2\2\2\u0115\u0116")
        buf.write(u"\3\2\2\2\u0116\u0117\3\2\2\2\u0117\u0118\7\23\2\2\u0118")
        buf.write(u"\u0119\58\35\2\u0119\u011a\7\24\2\2\u011a\u0125\3\2\2")
        buf.write(u"\2\u011b\u011d\7\37\2\2\u011c\u011b\3\2\2\2\u011c\u011d")
        buf.write(u"\3\2\2\2\u011d\u011e\3\2\2\2\u011e\u011f\7\23\2\2\u011f")
        buf.write(u"\u0120\58\35\2\u0120\u0121\5@!\2\u0121\u0122\58\35\2")
        buf.write(u"\u0122\u0123\7\24\2\2\u0123\u0125\3\2\2\2\u0124\u0104")
        buf.write(u"\3\2\2\2\u0124\u010a\3\2\2\2\u0124\u010e\3\2\2\2\u0124")
        buf.write(u"\u0115\3\2\2\2\u0124\u011c\3\2\2\2\u0125\u012c\3\2\2")
        buf.write(u"\2\u0126\u0127\f\4\2\2\u0127\u0128\5@!\2\u0128\u0129")
        buf.write(u"\58\35\5\u0129\u012b\3\2\2\2\u012a\u0126\3\2\2\2\u012b")
        buf.write(u"\u012e\3\2\2\2\u012c\u012a\3\2\2\2\u012c\u012d\3\2\2")
        buf.write(u"\2\u012d9\3\2\2\2\u012e\u012c\3\2\2\2\u012f\u0130\5<")
        buf.write(u"\37\2\u0130\u0131\5B\"\2\u0131\u0132\5> \2\u0132;\3\2")
        buf.write(u"\2\2\u0133\u0134\5\2\2\2\u0134=\3\2\2\2\u0135\u0136\5")
        buf.write(u"\2\2\2\u0136?\3\2\2\2\u0137\u0138\t\4\2\2\u0138A\3\2")
        buf.write(u"\2\2\u0139\u013a\t\5\2\2\u013aC\3\2\2\2\u013b\u013c\5")
        buf.write(u"*\26\2\u013c\u013d\5.\30\2\u013d\u013e\5\2\2\2\u013e")
        buf.write(u"E\3\2\2\2\u013f\u0140\5\32\16\2\u0140\u0141\7\f\2\2\u0141")
        buf.write(u"\u0142\5\2\2\2\u0142G\3\2\2\2\u0143\u0148\5\16\b\2\u0144")
        buf.write(u"\u0148\5(\25\2\u0145\u0148\5D#\2\u0146\u0148\5F$\2\u0147")
        buf.write(u"\u0143\3\2\2\2\u0147\u0144\3\2\2\2\u0147\u0145\3\2\2")
        buf.write(u"\2\u0147\u0146\3\2\2\2\u0148I\3\2\2\2\u0149\u014b\5H")
        buf.write(u"%\2\u014a\u0149\3\2\2\2\u014b\u014e\3\2\2\2\u014c\u014a")
        buf.write(u"\3\2\2\2\u014c\u014d\3\2\2\2\u014d\u014f\3\2\2\2\u014e")
        buf.write(u"\u014c\3\2\2\2\u014f\u0150\7\2\2\3\u0150K\3\2\2\2!RW")
        buf.write(u"]jqty\177\u0086\u008c\u008f\u00a2\u00a4\u00ad\u00b8\u00cc")
        buf.write(u"\u00d6\u00e5\u00ea\u00f0\u00f4\u0102\u0106\u010a\u010e")
        buf.write(u"\u0115\u011c\u0124\u012c\u0147\u014c")
        return buf.getvalue()


class NaClParser ( Parser ):

    grammarFileName = "NaCl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"'true'", u"'false'", u"'\\n'", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"'-'", u"'/'", u"'.'", 
                     u"':'", u"','", u"'#'", u"'{'", u"'}'", u"'['", u"']'", 
                     u"'('", u"')'", u"'\"'", u"'=='", u"'!='", u"'>'", 
                     u"'<'", u"'>='", u"'<='", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"<INVALID>", u"'if'", u"'else'", u"'//'", 
                     u"'/*'", u"'*/'" ]

    symbolicNames = [ u"<INVALID>", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                      u"Whitespace", u"IPv6", u"Number", u"Hyphen", u"Slash", 
                      u"Dot", u"Colon", u"Comma", u"Hash", u"Curly_bracket_start", 
                      u"Curly_bracket_end", u"Square_bracket_start", u"Square_bracket_end", 
                      u"Parenthesis_start", u"Parenthesis_end", u"Quotes", 
                      u"Equals", u"Not_equals", u"Greater_than", u"Less_than", 
                      u"Greater_or_equals", u"Less_or_equals", u"In", u"And", 
                      u"Or", u"Not", u"If", u"Else", u"Line_comment_start", 
                      u"Block_comment_start", u"Block_comment_end", u"Hash_comment", 
                      u"Line_comment", u"Block_comment", u"Identifier" ]

    RULE_value = 0
    RULE_primitive_type = 1
    RULE_numeric_type = 2
    RULE_bool_val = 3
    RULE_ipv4_cidr = 4
    RULE_cidr_mask = 5
    RULE_integer = 6
    RULE_decimal = 7
    RULE_ipv4_addr = 8
    RULE_ipv6_addr = 9
    RULE_rng = 10
    RULE_string = 11
    RULE_value_name = 12
    RULE_obj = 13
    RULE_key_value_list = 14
    RULE_key_value_pair = 15
    RULE_key = 16
    RULE_list_t = 17
    RULE_value_list = 18
    RULE_function = 19
    RULE_type_t = 20
    RULE_subtype = 21
    RULE_name = 22
    RULE_body = 23
    RULE_body_element = 24
    RULE_action = 25
    RULE_conditional = 26
    RULE_bool_expr = 27
    RULE_comparison = 28
    RULE_lhs = 29
    RULE_rhs = 30
    RULE_logical_operator = 31
    RULE_comparison_operator = 32
    RULE_typed_initializer = 33
    RULE_initializer = 34
    RULE_expr = 35
    RULE_prog = 36

    ruleNames =  [ u"value", u"primitive_type", u"numeric_type", u"bool_val", 
                   u"ipv4_cidr", u"cidr_mask", u"integer", u"decimal", u"ipv4_addr", 
                   u"ipv6_addr", u"rng", u"string", u"value_name", u"obj", 
                   u"key_value_list", u"key_value_pair", u"key", u"list_t", 
                   u"value_list", u"function", u"type_t", u"subtype", u"name", 
                   u"body", u"body_element", u"action", u"conditional", 
                   u"bool_expr", u"comparison", u"lhs", u"rhs", u"logical_operator", 
                   u"comparison_operator", u"typed_initializer", u"initializer", 
                   u"expr", u"prog" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    Whitespace=4
    IPv6=5
    Number=6
    Hyphen=7
    Slash=8
    Dot=9
    Colon=10
    Comma=11
    Hash=12
    Curly_bracket_start=13
    Curly_bracket_end=14
    Square_bracket_start=15
    Square_bracket_end=16
    Parenthesis_start=17
    Parenthesis_end=18
    Quotes=19
    Equals=20
    Not_equals=21
    Greater_than=22
    Less_than=23
    Greater_or_equals=24
    Less_or_equals=25
    In=26
    And=27
    Or=28
    Not=29
    If=30
    Else=31
    Line_comment_start=32
    Block_comment_start=33
    Block_comment_end=34
    Hash_comment=35
    Line_comment=36
    Block_comment=37
    Identifier=38

    def __init__(self, input, output=sys.stdout):
        super(NaClParser, self).__init__(input, output=output)
        self.checkVersion("4.7")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ValueContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ValueContext, self).__init__(parent, invokingState)
            self.parser = parser

        def primitive_type(self):
            return self.getTypedRuleContext(NaClParser.Primitive_typeContext,0)


        def rng(self):
            return self.getTypedRuleContext(NaClParser.RngContext,0)


        def string(self):
            return self.getTypedRuleContext(NaClParser.StringContext,0)


        def value_name(self):
            return self.getTypedRuleContext(NaClParser.Value_nameContext,0)


        def obj(self):
            return self.getTypedRuleContext(NaClParser.ObjContext,0)


        def list_t(self):
            return self.getTypedRuleContext(NaClParser.List_tContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_value

        def enterRule(self, listener):
            if hasattr(listener, "enterValue"):
                listener.enterValue(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitValue"):
                listener.exitValue(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitValue"):
                return visitor.visitValue(self)
            else:
                return visitor.visitChildren(self)




    def value(self):

        localctx = NaClParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_value)
        try:
            self.state = 80
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 74
                self.primitive_type()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 75
                self.rng()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 76
                self.string()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 77
                self.value_name()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 78
                self.obj()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 79
                self.list_t()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Primitive_typeContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Primitive_typeContext, self).__init__(parent, invokingState)
            self.parser = parser

        def numeric_type(self):
            return self.getTypedRuleContext(NaClParser.Numeric_typeContext,0)


        def bool_val(self):
            return self.getTypedRuleContext(NaClParser.Bool_valContext,0)


        def ipv4_cidr(self):
            return self.getTypedRuleContext(NaClParser.Ipv4_cidrContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_primitive_type

        def enterRule(self, listener):
            if hasattr(listener, "enterPrimitive_type"):
                listener.enterPrimitive_type(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPrimitive_type"):
                listener.exitPrimitive_type(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitPrimitive_type"):
                return visitor.visitPrimitive_type(self)
            else:
                return visitor.visitChildren(self)




    def primitive_type(self):

        localctx = NaClParser.Primitive_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_primitive_type)
        try:
            self.state = 85
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 82
                self.numeric_type()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 83
                self.bool_val()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 84
                self.ipv4_cidr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Numeric_typeContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Numeric_typeContext, self).__init__(parent, invokingState)
            self.parser = parser

        def integer(self):
            return self.getTypedRuleContext(NaClParser.IntegerContext,0)


        def decimal(self):
            return self.getTypedRuleContext(NaClParser.DecimalContext,0)


        def ipv4_addr(self):
            return self.getTypedRuleContext(NaClParser.Ipv4_addrContext,0)


        def ipv6_addr(self):
            return self.getTypedRuleContext(NaClParser.Ipv6_addrContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_numeric_type

        def enterRule(self, listener):
            if hasattr(listener, "enterNumeric_type"):
                listener.enterNumeric_type(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitNumeric_type"):
                listener.exitNumeric_type(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitNumeric_type"):
                return visitor.visitNumeric_type(self)
            else:
                return visitor.visitChildren(self)




    def numeric_type(self):

        localctx = NaClParser.Numeric_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_numeric_type)
        try:
            self.state = 91
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 87
                self.integer()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 88
                self.decimal()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 89
                self.ipv4_addr()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 90
                self.ipv6_addr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Bool_valContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Bool_valContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return NaClParser.RULE_bool_val

        def enterRule(self, listener):
            if hasattr(listener, "enterBool_val"):
                listener.enterBool_val(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBool_val"):
                listener.exitBool_val(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBool_val"):
                return visitor.visitBool_val(self)
            else:
                return visitor.visitChildren(self)




    def bool_val(self):

        localctx = NaClParser.Bool_valContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_bool_val)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            _la = self._input.LA(1)
            if not(_la==NaClParser.T__0 or _la==NaClParser.T__1):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ipv4_cidrContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Ipv4_cidrContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ipv4_addr(self):
            return self.getTypedRuleContext(NaClParser.Ipv4_addrContext,0)


        def cidr_mask(self):
            return self.getTypedRuleContext(NaClParser.Cidr_maskContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_ipv4_cidr

        def enterRule(self, listener):
            if hasattr(listener, "enterIpv4_cidr"):
                listener.enterIpv4_cidr(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitIpv4_cidr"):
                listener.exitIpv4_cidr(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitIpv4_cidr"):
                return visitor.visitIpv4_cidr(self)
            else:
                return visitor.visitChildren(self)




    def ipv4_cidr(self):

        localctx = NaClParser.Ipv4_cidrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_ipv4_cidr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self.ipv4_addr()
            self.state = 96
            self.cidr_mask()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Cidr_maskContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Cidr_maskContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Slash(self):
            return self.getToken(NaClParser.Slash, 0)

        def integer(self):
            return self.getTypedRuleContext(NaClParser.IntegerContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_cidr_mask

        def enterRule(self, listener):
            if hasattr(listener, "enterCidr_mask"):
                listener.enterCidr_mask(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitCidr_mask"):
                listener.exitCidr_mask(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitCidr_mask"):
                return visitor.visitCidr_mask(self)
            else:
                return visitor.visitChildren(self)




    def cidr_mask(self):

        localctx = NaClParser.Cidr_maskContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_cidr_mask)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 98
            self.match(NaClParser.Slash)
            self.state = 99
            self.integer()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class IntegerContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.IntegerContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Number(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Number)
            else:
                return self.getToken(NaClParser.Number, i)

        def Parenthesis_start(self):
            return self.getToken(NaClParser.Parenthesis_start, 0)

        def Hyphen(self):
            return self.getToken(NaClParser.Hyphen, 0)

        def Parenthesis_end(self):
            return self.getToken(NaClParser.Parenthesis_end, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_integer

        def enterRule(self, listener):
            if hasattr(listener, "enterInteger"):
                listener.enterInteger(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitInteger"):
                listener.exitInteger(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitInteger"):
                return visitor.visitInteger(self)
            else:
                return visitor.visitChildren(self)




    def integer(self):

        localctx = NaClParser.IntegerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_integer)
        self._la = 0 # Token type
        try:
            self.state = 114
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [NaClParser.Number]:
                self.enterOuterAlt(localctx, 1)
                self.state = 102 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 101
                        self.match(NaClParser.Number)

                    else:
                        raise NoViableAltException(self)
                    self.state = 104 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

                pass
            elif token in [NaClParser.Parenthesis_start]:
                self.enterOuterAlt(localctx, 2)
                self.state = 106
                self.match(NaClParser.Parenthesis_start)
                self.state = 107
                self.match(NaClParser.Hyphen)
                self.state = 109 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 108
                    self.match(NaClParser.Number)
                    self.state = 111 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==NaClParser.Number):
                        break

                self.state = 113
                self.match(NaClParser.Parenthesis_end)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class DecimalContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.DecimalContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Dot(self):
            return self.getToken(NaClParser.Dot, 0)

        def Number(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Number)
            else:
                return self.getToken(NaClParser.Number, i)

        def Parenthesis_start(self):
            return self.getToken(NaClParser.Parenthesis_start, 0)

        def Hyphen(self):
            return self.getToken(NaClParser.Hyphen, 0)

        def Parenthesis_end(self):
            return self.getToken(NaClParser.Parenthesis_end, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_decimal

        def enterRule(self, listener):
            if hasattr(listener, "enterDecimal"):
                listener.enterDecimal(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitDecimal"):
                listener.exitDecimal(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitDecimal"):
                return visitor.visitDecimal(self)
            else:
                return visitor.visitChildren(self)




    def decimal(self):

        localctx = NaClParser.DecimalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_decimal)
        self._la = 0 # Token type
        try:
            self.state = 141
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [NaClParser.Number]:
                self.enterOuterAlt(localctx, 1)
                self.state = 117 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 116
                    self.match(NaClParser.Number)
                    self.state = 119 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==NaClParser.Number):
                        break

                self.state = 121
                self.match(NaClParser.Dot)
                self.state = 123 
                self._errHandler.sync(self)
                _alt = 1
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt == 1:
                        self.state = 122
                        self.match(NaClParser.Number)

                    else:
                        raise NoViableAltException(self)
                    self.state = 125 
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

                pass
            elif token in [NaClParser.Parenthesis_start]:
                self.enterOuterAlt(localctx, 2)
                self.state = 127
                self.match(NaClParser.Parenthesis_start)
                self.state = 128
                self.match(NaClParser.Hyphen)
                self.state = 130 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 129
                    self.match(NaClParser.Number)
                    self.state = 132 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==NaClParser.Number):
                        break

                self.state = 134
                self.match(NaClParser.Dot)
                self.state = 136 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while True:
                    self.state = 135
                    self.match(NaClParser.Number)
                    self.state = 138 
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if not (_la==NaClParser.Number):
                        break

                self.state = 140
                self.match(NaClParser.Parenthesis_end)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ipv4_addrContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Ipv4_addrContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Number(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Number)
            else:
                return self.getToken(NaClParser.Number, i)

        def Dot(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Dot)
            else:
                return self.getToken(NaClParser.Dot, i)

        def getRuleIndex(self):
            return NaClParser.RULE_ipv4_addr

        def enterRule(self, listener):
            if hasattr(listener, "enterIpv4_addr"):
                listener.enterIpv4_addr(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitIpv4_addr"):
                listener.exitIpv4_addr(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitIpv4_addr"):
                return visitor.visitIpv4_addr(self)
            else:
                return visitor.visitChildren(self)




    def ipv4_addr(self):

        localctx = NaClParser.Ipv4_addrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_ipv4_addr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 143
            self.match(NaClParser.Number)
            self.state = 144
            self.match(NaClParser.Dot)
            self.state = 145
            self.match(NaClParser.Number)
            self.state = 146
            self.match(NaClParser.Dot)
            self.state = 147
            self.match(NaClParser.Number)
            self.state = 148
            self.match(NaClParser.Dot)
            self.state = 149
            self.match(NaClParser.Number)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Ipv6_addrContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Ipv6_addrContext, self).__init__(parent, invokingState)
            self.parser = parser

        def IPv6(self):
            return self.getToken(NaClParser.IPv6, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_ipv6_addr

        def enterRule(self, listener):
            if hasattr(listener, "enterIpv6_addr"):
                listener.enterIpv6_addr(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitIpv6_addr"):
                listener.exitIpv6_addr(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitIpv6_addr"):
                return visitor.visitIpv6_addr(self)
            else:
                return visitor.visitChildren(self)




    def ipv6_addr(self):

        localctx = NaClParser.Ipv6_addrContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_ipv6_addr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(NaClParser.IPv6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RngContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.RngContext, self).__init__(parent, invokingState)
            self.parser = parser

        def numeric_type(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.Numeric_typeContext)
            else:
                return self.getTypedRuleContext(NaClParser.Numeric_typeContext,i)


        def Hyphen(self):
            return self.getToken(NaClParser.Hyphen, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_rng

        def enterRule(self, listener):
            if hasattr(listener, "enterRng"):
                listener.enterRng(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitRng"):
                listener.exitRng(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitRng"):
                return visitor.visitRng(self)
            else:
                return visitor.visitChildren(self)




    def rng(self):

        localctx = NaClParser.RngContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_rng)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 153
            self.numeric_type()
            self.state = 154
            self.match(NaClParser.Hyphen)
            self.state = 155
            self.numeric_type()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class StringContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.StringContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Quotes(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Quotes)
            else:
                return self.getToken(NaClParser.Quotes, i)

        def getRuleIndex(self):
            return NaClParser.RULE_string

        def enterRule(self, listener):
            if hasattr(listener, "enterString"):
                listener.enterString(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitString"):
                listener.exitString(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitString"):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)




    def string(self):

        localctx = NaClParser.StringContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_string)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 157
            self.match(NaClParser.Quotes)
            self.state = 162
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << NaClParser.T__0) | (1 << NaClParser.T__1) | (1 << NaClParser.T__2) | (1 << NaClParser.Whitespace) | (1 << NaClParser.IPv6) | (1 << NaClParser.Number) | (1 << NaClParser.Hyphen) | (1 << NaClParser.Slash) | (1 << NaClParser.Dot) | (1 << NaClParser.Colon) | (1 << NaClParser.Comma) | (1 << NaClParser.Hash) | (1 << NaClParser.Curly_bracket_start) | (1 << NaClParser.Curly_bracket_end) | (1 << NaClParser.Square_bracket_start) | (1 << NaClParser.Square_bracket_end) | (1 << NaClParser.Parenthesis_start) | (1 << NaClParser.Parenthesis_end) | (1 << NaClParser.Equals) | (1 << NaClParser.Not_equals) | (1 << NaClParser.Greater_than) | (1 << NaClParser.Less_than) | (1 << NaClParser.Greater_or_equals) | (1 << NaClParser.Less_or_equals) | (1 << NaClParser.In) | (1 << NaClParser.And) | (1 << NaClParser.Or) | (1 << NaClParser.Not) | (1 << NaClParser.If) | (1 << NaClParser.Else) | (1 << NaClParser.Line_comment_start) | (1 << NaClParser.Block_comment_start) | (1 << NaClParser.Block_comment_end) | (1 << NaClParser.Hash_comment) | (1 << NaClParser.Line_comment) | (1 << NaClParser.Block_comment) | (1 << NaClParser.Identifier))) != 0):
                self.state = 160
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
                if la_ == 1:
                    self.state = 158
                    _la = self._input.LA(1)
                    if _la <= 0 or _la==NaClParser.Quotes:
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    pass

                elif la_ == 2:
                    self.state = 159
                    self.match(NaClParser.T__2)
                    pass


                self.state = 164
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 165
            self.match(NaClParser.Quotes)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Value_nameContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Value_nameContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(NaClParser.Identifier, 0)

        def Dot(self):
            return self.getToken(NaClParser.Dot, 0)

        def value_name(self):
            return self.getTypedRuleContext(NaClParser.Value_nameContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_value_name

        def enterRule(self, listener):
            if hasattr(listener, "enterValue_name"):
                listener.enterValue_name(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitValue_name"):
                listener.exitValue_name(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitValue_name"):
                return visitor.visitValue_name(self)
            else:
                return visitor.visitChildren(self)




    def value_name(self):

        localctx = NaClParser.Value_nameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_value_name)
        try:
            self.state = 171
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 167
                self.match(NaClParser.Identifier)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 168
                self.match(NaClParser.Identifier)
                self.state = 169
                self.match(NaClParser.Dot)
                self.state = 170
                self.value_name()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ObjContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ObjContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Curly_bracket_start(self):
            return self.getToken(NaClParser.Curly_bracket_start, 0)

        def key_value_list(self):
            return self.getTypedRuleContext(NaClParser.Key_value_listContext,0)


        def Curly_bracket_end(self):
            return self.getToken(NaClParser.Curly_bracket_end, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_obj

        def enterRule(self, listener):
            if hasattr(listener, "enterObj"):
                listener.enterObj(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitObj"):
                listener.exitObj(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitObj"):
                return visitor.visitObj(self)
            else:
                return visitor.visitChildren(self)




    def obj(self):

        localctx = NaClParser.ObjContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_obj)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 173
            self.match(NaClParser.Curly_bracket_start)
            self.state = 174
            self.key_value_list()
            self.state = 175
            self.match(NaClParser.Curly_bracket_end)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Key_value_listContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Key_value_listContext, self).__init__(parent, invokingState)
            self.parser = parser

        def key_value_pair(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.Key_value_pairContext)
            else:
                return self.getTypedRuleContext(NaClParser.Key_value_pairContext,i)


        def Comma(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Comma)
            else:
                return self.getToken(NaClParser.Comma, i)

        def getRuleIndex(self):
            return NaClParser.RULE_key_value_list

        def enterRule(self, listener):
            if hasattr(listener, "enterKey_value_list"):
                listener.enterKey_value_list(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitKey_value_list"):
                listener.exitKey_value_list(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitKey_value_list"):
                return visitor.visitKey_value_list(self)
            else:
                return visitor.visitChildren(self)




    def key_value_list(self):

        localctx = NaClParser.Key_value_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_key_value_list)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 182
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,14,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 177
                    self.key_value_pair()
                    self.state = 178
                    self.match(NaClParser.Comma) 
                self.state = 184
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,14,self._ctx)

            self.state = 185
            self.key_value_pair()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Key_value_pairContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Key_value_pairContext, self).__init__(parent, invokingState)
            self.parser = parser

        def key(self):
            return self.getTypedRuleContext(NaClParser.KeyContext,0)


        def Colon(self):
            return self.getToken(NaClParser.Colon, 0)

        def value(self):
            return self.getTypedRuleContext(NaClParser.ValueContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_key_value_pair

        def enterRule(self, listener):
            if hasattr(listener, "enterKey_value_pair"):
                listener.enterKey_value_pair(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitKey_value_pair"):
                listener.exitKey_value_pair(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitKey_value_pair"):
                return visitor.visitKey_value_pair(self)
            else:
                return visitor.visitChildren(self)




    def key_value_pair(self):

        localctx = NaClParser.Key_value_pairContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_key_value_pair)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self.key()
            self.state = 188
            self.match(NaClParser.Colon)
            self.state = 189
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class KeyContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.KeyContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(NaClParser.Identifier, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_key

        def enterRule(self, listener):
            if hasattr(listener, "enterKey"):
                listener.enterKey(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitKey"):
                listener.exitKey(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitKey"):
                return visitor.visitKey(self)
            else:
                return visitor.visitChildren(self)




    def key(self):

        localctx = NaClParser.KeyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_key)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 191
            self.match(NaClParser.Identifier)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class List_tContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.List_tContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Square_bracket_start(self):
            return self.getToken(NaClParser.Square_bracket_start, 0)

        def value_list(self):
            return self.getTypedRuleContext(NaClParser.Value_listContext,0)


        def Square_bracket_end(self):
            return self.getToken(NaClParser.Square_bracket_end, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_list_t

        def enterRule(self, listener):
            if hasattr(listener, "enterList_t"):
                listener.enterList_t(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitList_t"):
                listener.exitList_t(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitList_t"):
                return visitor.visitList_t(self)
            else:
                return visitor.visitChildren(self)




    def list_t(self):

        localctx = NaClParser.List_tContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_list_t)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 193
            self.match(NaClParser.Square_bracket_start)
            self.state = 194
            self.value_list()
            self.state = 195
            self.match(NaClParser.Square_bracket_end)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Value_listContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Value_listContext, self).__init__(parent, invokingState)
            self.parser = parser

        def value(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.ValueContext)
            else:
                return self.getTypedRuleContext(NaClParser.ValueContext,i)


        def Comma(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Comma)
            else:
                return self.getToken(NaClParser.Comma, i)

        def getRuleIndex(self):
            return NaClParser.RULE_value_list

        def enterRule(self, listener):
            if hasattr(listener, "enterValue_list"):
                listener.enterValue_list(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitValue_list"):
                listener.exitValue_list(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitValue_list"):
                return visitor.visitValue_list(self)
            else:
                return visitor.visitChildren(self)




    def value_list(self):

        localctx = NaClParser.Value_listContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_value_list)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 202
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,15,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 197
                    self.value()
                    self.state = 198
                    self.match(NaClParser.Comma) 
                self.state = 204
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,15,self._ctx)

            self.state = 205
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class FunctionContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.FunctionContext, self).__init__(parent, invokingState)
            self.parser = parser

        def type_t(self):
            return self.getTypedRuleContext(NaClParser.Type_tContext,0)


        def Colon(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Colon)
            else:
                return self.getToken(NaClParser.Colon, i)

        def subtype(self):
            return self.getTypedRuleContext(NaClParser.SubtypeContext,0)


        def Curly_bracket_start(self):
            return self.getToken(NaClParser.Curly_bracket_start, 0)

        def body(self):
            return self.getTypedRuleContext(NaClParser.BodyContext,0)


        def Curly_bracket_end(self):
            return self.getToken(NaClParser.Curly_bracket_end, 0)

        def name(self):
            return self.getTypedRuleContext(NaClParser.NameContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_function

        def enterRule(self, listener):
            if hasattr(listener, "enterFunction"):
                listener.enterFunction(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitFunction"):
                listener.exitFunction(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitFunction"):
                return visitor.visitFunction(self)
            else:
                return visitor.visitChildren(self)




    def function(self):

        localctx = NaClParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            self.type_t()
            self.state = 208
            self.match(NaClParser.Colon)
            self.state = 209
            self.match(NaClParser.Colon)
            self.state = 210
            self.subtype()
            self.state = 212
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==NaClParser.Identifier:
                self.state = 211
                self.name()


            self.state = 214
            self.match(NaClParser.Curly_bracket_start)
            self.state = 215
            self.body()
            self.state = 216
            self.match(NaClParser.Curly_bracket_end)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Type_tContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Type_tContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(NaClParser.Identifier, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_type_t

        def enterRule(self, listener):
            if hasattr(listener, "enterType_t"):
                listener.enterType_t(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitType_t"):
                listener.exitType_t(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitType_t"):
                return visitor.visitType_t(self)
            else:
                return visitor.visitChildren(self)




    def type_t(self):

        localctx = NaClParser.Type_tContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_type_t)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 218
            self.match(NaClParser.Identifier)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class SubtypeContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.SubtypeContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(NaClParser.Identifier, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_subtype

        def enterRule(self, listener):
            if hasattr(listener, "enterSubtype"):
                listener.enterSubtype(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitSubtype"):
                listener.exitSubtype(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitSubtype"):
                return visitor.visitSubtype(self)
            else:
                return visitor.visitChildren(self)




    def subtype(self):

        localctx = NaClParser.SubtypeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_subtype)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 220
            self.match(NaClParser.Identifier)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class NameContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.NameContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Identifier(self):
            return self.getToken(NaClParser.Identifier, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_name

        def enterRule(self, listener):
            if hasattr(listener, "enterName"):
                listener.enterName(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitName"):
                listener.exitName(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitName"):
                return visitor.visitName(self)
            else:
                return visitor.visitChildren(self)




    def name(self):

        localctx = NaClParser.NameContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_name)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.match(NaClParser.Identifier)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class BodyContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.BodyContext, self).__init__(parent, invokingState)
            self.parser = parser

        def body_element(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.Body_elementContext)
            else:
                return self.getTypedRuleContext(NaClParser.Body_elementContext,i)


        def getRuleIndex(self):
            return NaClParser.RULE_body

        def enterRule(self, listener):
            if hasattr(listener, "enterBody"):
                listener.enterBody(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBody"):
                listener.exitBody(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBody"):
                return visitor.visitBody(self)
            else:
                return visitor.visitChildren(self)




    def body(self):

        localctx = NaClParser.BodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 224
                self.body_element()
                self.state = 227 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==NaClParser.If or _la==NaClParser.Identifier):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Body_elementContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Body_elementContext, self).__init__(parent, invokingState)
            self.parser = parser

        def function(self):
            return self.getTypedRuleContext(NaClParser.FunctionContext,0)


        def action(self):
            return self.getTypedRuleContext(NaClParser.ActionContext,0)


        def conditional(self):
            return self.getTypedRuleContext(NaClParser.ConditionalContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_body_element

        def enterRule(self, listener):
            if hasattr(listener, "enterBody_element"):
                listener.enterBody_element(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBody_element"):
                listener.exitBody_element(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBody_element"):
                return visitor.visitBody_element(self)
            else:
                return visitor.visitChildren(self)




    def body_element(self):

        localctx = NaClParser.Body_elementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_body_element)
        try:
            self.state = 232
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 229
                self.function()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 230
                self.action()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 231
                self.conditional()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ActionContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ActionContext, self).__init__(parent, invokingState)
            self.parser = parser

        def name(self):
            return self.getTypedRuleContext(NaClParser.NameContext,0)


        def Parenthesis_start(self):
            return self.getToken(NaClParser.Parenthesis_start, 0)

        def Parenthesis_end(self):
            return self.getToken(NaClParser.Parenthesis_end, 0)

        def value_list(self):
            return self.getTypedRuleContext(NaClParser.Value_listContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_action

        def enterRule(self, listener):
            if hasattr(listener, "enterAction"):
                listener.enterAction(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitAction"):
                listener.exitAction(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitAction"):
                return visitor.visitAction(self)
            else:
                return visitor.visitChildren(self)




    def action(self):

        localctx = NaClParser.ActionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_action)
        self._la = 0 # Token type
        try:
            self.state = 242
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 234
                self.name()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 235
                self.name()
                self.state = 236
                self.match(NaClParser.Parenthesis_start)
                self.state = 238
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << NaClParser.T__0) | (1 << NaClParser.T__1) | (1 << NaClParser.IPv6) | (1 << NaClParser.Number) | (1 << NaClParser.Curly_bracket_start) | (1 << NaClParser.Square_bracket_start) | (1 << NaClParser.Parenthesis_start) | (1 << NaClParser.Quotes) | (1 << NaClParser.Identifier))) != 0):
                    self.state = 237
                    self.value_list()


                self.state = 240
                self.match(NaClParser.Parenthesis_end)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ConditionalContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ConditionalContext, self).__init__(parent, invokingState)
            self.parser = parser

        def If(self):
            return self.getToken(NaClParser.If, 0)

        def Parenthesis_start(self):
            return self.getToken(NaClParser.Parenthesis_start, 0)

        def bool_expr(self):
            return self.getTypedRuleContext(NaClParser.Bool_exprContext,0)


        def Parenthesis_end(self):
            return self.getToken(NaClParser.Parenthesis_end, 0)

        def Curly_bracket_start(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Curly_bracket_start)
            else:
                return self.getToken(NaClParser.Curly_bracket_start, i)

        def body(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.BodyContext)
            else:
                return self.getTypedRuleContext(NaClParser.BodyContext,i)


        def Curly_bracket_end(self, i=None):
            if i is None:
                return self.getTokens(NaClParser.Curly_bracket_end)
            else:
                return self.getToken(NaClParser.Curly_bracket_end, i)

        def Else(self):
            return self.getToken(NaClParser.Else, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_conditional

        def enterRule(self, listener):
            if hasattr(listener, "enterConditional"):
                listener.enterConditional(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitConditional"):
                listener.exitConditional(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitConditional"):
                return visitor.visitConditional(self)
            else:
                return visitor.visitChildren(self)




    def conditional(self):

        localctx = NaClParser.ConditionalContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_conditional)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 244
            self.match(NaClParser.If)
            self.state = 245
            self.match(NaClParser.Parenthesis_start)
            self.state = 246
            self.bool_expr(0)
            self.state = 247
            self.match(NaClParser.Parenthesis_end)
            self.state = 248
            self.match(NaClParser.Curly_bracket_start)
            self.state = 249
            self.body()
            self.state = 250
            self.match(NaClParser.Curly_bracket_end)
            self.state = 256
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==NaClParser.Else:
                self.state = 251
                self.match(NaClParser.Else)
                self.state = 252
                self.match(NaClParser.Curly_bracket_start)
                self.state = 253
                self.body()
                self.state = 254
                self.match(NaClParser.Curly_bracket_end)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Bool_exprContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Bool_exprContext, self).__init__(parent, invokingState)
            self.parser = parser

        def value(self):
            return self.getTypedRuleContext(NaClParser.ValueContext,0)


        def Not(self):
            return self.getToken(NaClParser.Not, 0)

        def comparison(self):
            return self.getTypedRuleContext(NaClParser.ComparisonContext,0)


        def Parenthesis_start(self):
            return self.getToken(NaClParser.Parenthesis_start, 0)

        def Parenthesis_end(self):
            return self.getToken(NaClParser.Parenthesis_end, 0)

        def bool_expr(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.Bool_exprContext)
            else:
                return self.getTypedRuleContext(NaClParser.Bool_exprContext,i)


        def logical_operator(self):
            return self.getTypedRuleContext(NaClParser.Logical_operatorContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_bool_expr

        def enterRule(self, listener):
            if hasattr(listener, "enterBool_expr"):
                listener.enterBool_expr(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBool_expr"):
                listener.exitBool_expr(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBool_expr"):
                return visitor.visitBool_expr(self)
            else:
                return visitor.visitChildren(self)



    def bool_expr(self, _p=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = NaClParser.Bool_exprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 54
        self.enterRecursionRule(localctx, 54, self.RULE_bool_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 290
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
            if la_ == 1:
                self.state = 260
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==NaClParser.Not:
                    self.state = 259
                    self.match(NaClParser.Not)


                self.state = 262
                self.value()
                pass

            elif la_ == 2:
                self.state = 264
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==NaClParser.Not:
                    self.state = 263
                    self.match(NaClParser.Not)


                self.state = 266
                self.comparison()
                pass

            elif la_ == 3:
                self.state = 268
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==NaClParser.Not:
                    self.state = 267
                    self.match(NaClParser.Not)


                self.state = 270
                self.match(NaClParser.Parenthesis_start)
                self.state = 271
                self.comparison()
                self.state = 272
                self.match(NaClParser.Parenthesis_end)
                pass

            elif la_ == 4:
                self.state = 275
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==NaClParser.Not:
                    self.state = 274
                    self.match(NaClParser.Not)


                self.state = 277
                self.match(NaClParser.Parenthesis_start)
                self.state = 278
                self.bool_expr(0)
                self.state = 279
                self.match(NaClParser.Parenthesis_end)
                pass

            elif la_ == 5:
                self.state = 282
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==NaClParser.Not:
                    self.state = 281
                    self.match(NaClParser.Not)


                self.state = 284
                self.match(NaClParser.Parenthesis_start)
                self.state = 285
                self.bool_expr(0)
                self.state = 286
                self.logical_operator()
                self.state = 287
                self.bool_expr(0)
                self.state = 288
                self.match(NaClParser.Parenthesis_end)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 298
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,28,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = NaClParser.Bool_exprContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_bool_expr)
                    self.state = 292
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 293
                    self.logical_operator()
                    self.state = 294
                    self.bool_expr(3) 
                self.state = 300
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,28,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class ComparisonContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ComparisonContext, self).__init__(parent, invokingState)
            self.parser = parser

        def lhs(self):
            return self.getTypedRuleContext(NaClParser.LhsContext,0)


        def comparison_operator(self):
            return self.getTypedRuleContext(NaClParser.Comparison_operatorContext,0)


        def rhs(self):
            return self.getTypedRuleContext(NaClParser.RhsContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_comparison

        def enterRule(self, listener):
            if hasattr(listener, "enterComparison"):
                listener.enterComparison(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitComparison"):
                listener.exitComparison(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitComparison"):
                return visitor.visitComparison(self)
            else:
                return visitor.visitChildren(self)




    def comparison(self):

        localctx = NaClParser.ComparisonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_comparison)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 301
            self.lhs()
            self.state = 302
            self.comparison_operator()
            self.state = 303
            self.rhs()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class LhsContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.LhsContext, self).__init__(parent, invokingState)
            self.parser = parser

        def value(self):
            return self.getTypedRuleContext(NaClParser.ValueContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_lhs

        def enterRule(self, listener):
            if hasattr(listener, "enterLhs"):
                listener.enterLhs(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitLhs"):
                listener.exitLhs(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitLhs"):
                return visitor.visitLhs(self)
            else:
                return visitor.visitChildren(self)




    def lhs(self):

        localctx = NaClParser.LhsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_lhs)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 305
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class RhsContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.RhsContext, self).__init__(parent, invokingState)
            self.parser = parser

        def value(self):
            return self.getTypedRuleContext(NaClParser.ValueContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_rhs

        def enterRule(self, listener):
            if hasattr(listener, "enterRhs"):
                listener.enterRhs(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitRhs"):
                listener.exitRhs(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitRhs"):
                return visitor.visitRhs(self)
            else:
                return visitor.visitChildren(self)




    def rhs(self):

        localctx = NaClParser.RhsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_rhs)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 307
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Logical_operatorContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Logical_operatorContext, self).__init__(parent, invokingState)
            self.parser = parser

        def And(self):
            return self.getToken(NaClParser.And, 0)

        def Or(self):
            return self.getToken(NaClParser.Or, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_logical_operator

        def enterRule(self, listener):
            if hasattr(listener, "enterLogical_operator"):
                listener.enterLogical_operator(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitLogical_operator"):
                listener.exitLogical_operator(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitLogical_operator"):
                return visitor.visitLogical_operator(self)
            else:
                return visitor.visitChildren(self)




    def logical_operator(self):

        localctx = NaClParser.Logical_operatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_logical_operator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 309
            _la = self._input.LA(1)
            if not(_la==NaClParser.And or _la==NaClParser.Or):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Comparison_operatorContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Comparison_operatorContext, self).__init__(parent, invokingState)
            self.parser = parser

        def Equals(self):
            return self.getToken(NaClParser.Equals, 0)

        def Not_equals(self):
            return self.getToken(NaClParser.Not_equals, 0)

        def Greater_than(self):
            return self.getToken(NaClParser.Greater_than, 0)

        def Less_than(self):
            return self.getToken(NaClParser.Less_than, 0)

        def Greater_or_equals(self):
            return self.getToken(NaClParser.Greater_or_equals, 0)

        def Less_or_equals(self):
            return self.getToken(NaClParser.Less_or_equals, 0)

        def In(self):
            return self.getToken(NaClParser.In, 0)

        def getRuleIndex(self):
            return NaClParser.RULE_comparison_operator

        def enterRule(self, listener):
            if hasattr(listener, "enterComparison_operator"):
                listener.enterComparison_operator(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitComparison_operator"):
                listener.exitComparison_operator(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitComparison_operator"):
                return visitor.visitComparison_operator(self)
            else:
                return visitor.visitChildren(self)




    def comparison_operator(self):

        localctx = NaClParser.Comparison_operatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_comparison_operator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 311
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << NaClParser.Equals) | (1 << NaClParser.Not_equals) | (1 << NaClParser.Greater_than) | (1 << NaClParser.Less_than) | (1 << NaClParser.Greater_or_equals) | (1 << NaClParser.Less_or_equals) | (1 << NaClParser.In))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Typed_initializerContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.Typed_initializerContext, self).__init__(parent, invokingState)
            self.parser = parser

        def type_t(self):
            return self.getTypedRuleContext(NaClParser.Type_tContext,0)


        def name(self):
            return self.getTypedRuleContext(NaClParser.NameContext,0)


        def value(self):
            return self.getTypedRuleContext(NaClParser.ValueContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_typed_initializer

        def enterRule(self, listener):
            if hasattr(listener, "enterTyped_initializer"):
                listener.enterTyped_initializer(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitTyped_initializer"):
                listener.exitTyped_initializer(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitTyped_initializer"):
                return visitor.visitTyped_initializer(self)
            else:
                return visitor.visitChildren(self)




    def typed_initializer(self):

        localctx = NaClParser.Typed_initializerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_typed_initializer)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 313
            self.type_t()
            self.state = 314
            self.name()
            self.state = 315
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class InitializerContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.InitializerContext, self).__init__(parent, invokingState)
            self.parser = parser

        def value_name(self):
            return self.getTypedRuleContext(NaClParser.Value_nameContext,0)


        def Colon(self):
            return self.getToken(NaClParser.Colon, 0)

        def value(self):
            return self.getTypedRuleContext(NaClParser.ValueContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_initializer

        def enterRule(self, listener):
            if hasattr(listener, "enterInitializer"):
                listener.enterInitializer(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitInitializer"):
                listener.exitInitializer(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitInitializer"):
                return visitor.visitInitializer(self)
            else:
                return visitor.visitChildren(self)




    def initializer(self):

        localctx = NaClParser.InitializerContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_initializer)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 317
            self.value_name()
            self.state = 318
            self.match(NaClParser.Colon)
            self.state = 319
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ExprContext, self).__init__(parent, invokingState)
            self.parser = parser

        def integer(self):
            return self.getTypedRuleContext(NaClParser.IntegerContext,0)


        def function(self):
            return self.getTypedRuleContext(NaClParser.FunctionContext,0)


        def typed_initializer(self):
            return self.getTypedRuleContext(NaClParser.Typed_initializerContext,0)


        def initializer(self):
            return self.getTypedRuleContext(NaClParser.InitializerContext,0)


        def getRuleIndex(self):
            return NaClParser.RULE_expr

        def enterRule(self, listener):
            if hasattr(listener, "enterExpr"):
                listener.enterExpr(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitExpr"):
                listener.exitExpr(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitExpr"):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)




    def expr(self):

        localctx = NaClParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_expr)
        try:
            self.state = 325
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 321
                self.integer()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 322
                self.function()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 323
                self.typed_initializer()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 324
                self.initializer()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ProgContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(NaClParser.ProgContext, self).__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(NaClParser.EOF, 0)

        def expr(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(NaClParser.ExprContext)
            else:
                return self.getTypedRuleContext(NaClParser.ExprContext,i)


        def getRuleIndex(self):
            return NaClParser.RULE_prog

        def enterRule(self, listener):
            if hasattr(listener, "enterProg"):
                listener.enterProg(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitProg"):
                listener.exitProg(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitProg"):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = NaClParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 330
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << NaClParser.Number) | (1 << NaClParser.Parenthesis_start) | (1 << NaClParser.Identifier))) != 0):
                self.state = 327
                self.expr()
                self.state = 332
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 333
            self.match(NaClParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx, ruleIndex, predIndex):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[27] = self.bool_expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def bool_expr_sempred(self, localctx, predIndex):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         




